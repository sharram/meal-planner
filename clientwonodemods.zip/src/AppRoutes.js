// client/src/AppRoutes.js
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './components/home';
import About from './components/about';
import Contact from './components/contact';
import Login from './components/login';
import Register from './components/register';
import RecipeInfo from './components/recipeinfo';
import RecipeList from './components/recipelist';
import Recipe from './components/recipe';
import AddRecipe from './components/AddRecipe';
import ForgotPassword from './components/ForgotPassword';

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} /> {/* Default route set to Login */}
      <Route path="/register" element={<Register />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/home" element={<Home />} />
      <Route path="/recipeinfo" element={<RecipeInfo />} />
      <Route path="/recipelist" element={<RecipeList />} />
      <Route path="/recipe" element={<Recipe />} />
      <Route path="/AddRecipe" element={<AddRecipe />} />
      <Route path="/ForgotPassword" element={<ForgotPassword />} />
      {/*<Route path="/add-recipe" element={<RecipeForm />} />*/}
    </Routes>
  );
}

export default AppRoutes;
