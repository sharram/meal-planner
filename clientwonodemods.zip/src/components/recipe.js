import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

const Recipe = () => {
  const { id } = useParams();
  const [recipe, setRecipe] = useState(null);
  const [error, setError] = useState(''); // Initialize error as an empty string

  useEffect(() => {
    const fetchRecipe = async () => {
      try {
        const response = await fetch(`http://localhost:5000/recipes/${id}`);
        if (!response.ok) {
          throw new Error('Failed to fetch recipe');
        }
        const data = await response.json();
        setRecipe(data);
      } catch (err) {
        setError('Error fetching recipe');
        console.error('Error:', err);
      }
    };

    fetchRecipe();
  }, [id]);

  // Conditional rendering based on error and recipe states
  if (error) {
    return <div>{error}</div>; // Display error message
  }

  if (!recipe) {
    return <div>Loading...</div>; // Display loading message
  }


    return (
        <div>
            <h1>Recipe List</h1>
            {error && <p>{error}</p>}
            <div>
            {recipe ? (
        <>
          <h1>{recipe.name}</h1>
          <p>{recipe.description}</p>
          <img src={recipe.photoUrl} alt={recipe.name} />
          {/* Additional details */}
        </>
      ) : (
        <p>Loading...</p>
      )}
            </div>
        </div>
    );
};

export default Recipe;
