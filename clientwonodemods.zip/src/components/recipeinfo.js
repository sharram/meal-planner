import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import '../styles.css';

function RecipeInfo() {
  
  const styles = {
    homeContainer: {
      fontFamily: 'Arial, sans-serif',
      margin: 0,
      padding: 0,
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      backgroundImage: 'url("file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/emerald.jpg")',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      color: 'white',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '1rem 1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
    },
    logo: {
      fontSize: '2rem',
      fontWeight: 'bold',
      color: 'white',
    },
    navbar: {
      display: 'flex',
      alignItems: 'center',
      gap: '1.5rem',
    },
    navLink: {
      textDecoration: 'none',
      color: 'white',
      fontWeight: '500',
      transition: 'color 0.3s ease',
    },
    signIn: {
      //backgroundColor: '#ff6b6b',
      color: '#dccf67',
      padding: '0.5rem 1rem',
      borderRadius: '4px',
    },
    
    footer: {
      textAlign: 'center',
      padding: '1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
      color: 'white',
    },
  };
  return (
    <div style={styles.homeContainer}>
      {/* Add Font Awesome link in the document head */}
      <Helmet>
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        />
      </Helmet>

  
      <header style={styles.header}>
        <div>
          <h1 style={styles.logo}>OneStopGo</h1>
        </div>
        <nav style={styles.navbar}>
          {/*<a href="/login" style={{...styles.navLink, ...styles.signIn}}>Sign In</a>*/}
          <a href="/home" style={styles.navLink}>Home</a>
          <a href="/" style={styles.navLink}>Recipes</a>
          <a href="/about" style={styles.navLink}>About Us</a>
          <a href="/contact" style={styles.navLink}>Contact Us</a>
        </nav>
      </header>

      
      <main className="categories">
        {/* Diet Icons Section */}
        <section className="diet-icons">
          <h2><wf>Choose Your Meal Plan</wf></h2>
          <div className="icon-container">
            <Link to="/recipelist/diabetic" className="icon-item">
              <i className="fas fa-apple-alt"></i>
              <p>Diabetic Diet</p>
            </Link>
            <Link to="/recipelist/pcos" className="icon-item">
              <i className="fas fa-female"></i>
              <p>PCOS<br />Diet</p>
            </Link>
            <Link to="/recipelist/workout" className="icon-item">
              <i className="fas fa-dumbbell"></i>
              <p>Workout Diet</p>
            </Link>
            <Link to="/recipelist/school" className="icon-item">
              <i className="fas fa-school"></i>
              <p>School Lunches</p>
            </Link>
            <Link to="/AddRecipe" className="icon-item">
              <i className="fas fa-cutlery"></i>
              <p>Share Your Own Recipe!</p>
            </Link>
          </div>
        </section>
      </main>
      <bgimg></bgimg>
      <footer style={styles.footer}>
        <p>&copy; 2024 Meal Planner</p>
      </footer>
    </div>
  );
}

export default RecipeInfo;
