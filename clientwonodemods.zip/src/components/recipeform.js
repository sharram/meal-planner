// AddRecipe.js
import React, { useState } from 'react';

function AddRecipe() {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [instructions, setInstructions] = useState('');
  const [image, setImage] = useState(null);
  const [message, setMessage] = useState('');

  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('title', title);
    formData.append('category', category);
    formData.append('ingredients', ingredients);
    formData.append('instructions', instructions);
    formData.append('image', image);

    try {
      const response = await fetch('http://localhost:5000/add-recipe', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        setMessage('Recipe added successfully');
      } else {
        setMessage('Failed to add recipe');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('An error occurred');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add New Recipe</h2>
      <input type="text" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} required />
      <input type="text" placeholder="Category" value={category} onChange={(e) => setCategory(e.target.value)} required />
      <textarea placeholder="Ingredients" value={ingredients} onChange={(e) => setIngredients(e.target.value)} required />
      <textarea placeholder="Instructions" value={instructions} onChange={(e) => setInstructions(e.target.value)} required />
      <input type="file" onChange={handleImageChange} required />
      <button type="submit">Add Recipe</button>
      <p>{message}</p>
    </form>
  );
}

export default AddRecipe;
