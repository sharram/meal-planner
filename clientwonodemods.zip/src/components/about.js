import React from 'react';
import { Link } from 'react-router-dom';
import '../styles.css'; // Import the CSS file

function About() {
  const styles = {
    homeContainer: {
      fontFamily: 'Arial, sans-serif',
      margin: 0,
      padding: 0,
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      backgroundImage: 'url("file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/emerald.jpg")',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      color: 'white',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '1rem 1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
    },
    logo: {
      fontSize: '2rem',
      fontWeight: 'bold',
      color: 'white',
    },
    navbar: {
      display: 'flex',
      alignItems: 'center',
      gap: '1.5rem',
    },
    navLink: {
      textDecoration: 'none',
      color: 'white',
      fontWeight: '500',
      transition: 'color 0.3s ease',
    },
    signIn: {
      //backgroundColor: '#ff6b6b',
      color: '#dccf67',
      padding: '0.5rem 1rem',
      borderRadius: '4px',
    },
    
    footer: {
      textAlign: 'center',
      padding: '1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
      color: 'white',
    },
  };
  return (
    
    <div style={styles.homeContainer}>
      <header style={styles.header}>
        <div>
          <h1 style={styles.logo}>OneStopGo</h1>
        </div>
        <nav style={styles.navbar}>
          <a href="/login" style={{...styles.navLink, ...styles.signIn}}>Sign In</a>
          <a href="/home" style={styles.navLink}>Home</a>
          <a href="/" style={styles.navLink}>About Us</a>
          <a href="/contact" style={styles.navLink}>Contact Us</a>
        </nav>
      </header>
      <main>
        <section>
          <div className="container">
            <div className="cubed">
              <h2>OneStopGo</h2>
              <br />
              <p>
                We are dedicated to helping you create balanced meals that fit your health and dietary needs. Whether you're managing conditions like diabetes, PCOS, or simply looking for healthy meal options for school lunches or workout routines, we’ve got you covered. Our platform offers personalized meal plans based on your unique requirements, and with our easy-to-follow recipes, you can confidently prepare delicious and health-conscious meals at home. 
                <br />
                <br />
                You can explore meal categories like diabetic-friendly options, PCOS meals, workout diets, and even share your own recipes with our community. Plus, our user-friendly interface makes meal planning fun and engaging, providing all the tools you need to stay on track with your health goals. Join us today to embark on your journey to healthier eating!
              </p>
            </div>
          </div>
          <bgimg></bgimg>
        </section>
      </main>

      <footer style={styles.footer}>
        <p>&copy; 2024 Meal Planner</p>
      </footer>
    </div>
  );
}

export default About;
