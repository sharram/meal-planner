import React, { useState } from 'react';
//import { Link } from 'react-router-dom';
import '../styles.css'; // Import the CSS file

function AddRecipe() {
  // src/components/AddRecipe.js
  const [foodType, setFoodType] = useState('');
  

const [recipe, setRecipe] = useState({
  name: '',
  ingredients: '',
  instructions: '',
  category: 'diabetic',
  description: '', // Add description field
  image: null,
});

const handleChange = (e) => {
  const { name, value } = e.target;
  setRecipe((prevRecipe) => ({
    ...prevRecipe,
    [name]: value,
  }));
  setFoodType(e.target.value); // Update the 'foodType' state based on the selected radio button
};

const handleImageChange = (e) => {
  setRecipe((prevRecipe) => ({
    ...prevRecipe,
    image: e.target.files[0],
  }));
};

const styles = {
  homeContainer: {
    fontFamily: 'Arial, sans-serif',
    margin: 0,
    padding: 0,
    height: '100vh',
    display: 'flex',
    flexDirection: 'column',
    backgroundImage: 'url("file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/emerald.jpg")',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    color: 'white',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '1rem 1rem',
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  logo: {
    fontSize: '2rem',
    fontWeight: 'bold',
    color: 'white',
  },
  navbar: {
    display: 'flex',
    alignItems: 'center',
    gap: '1.5rem',
  },
  navLink: {
    textDecoration: 'none',
    color: 'white',
    fontWeight: '500',
    transition: 'color 0.3s ease',
  },
  signIn: {
    //backgroundColor: '#ff6b6b',
    color: '#dccf67',
    padding: '0.5rem 1rem',
    borderRadius: '4px',
  },
  
  footer: {
    textAlign: 'center',
    padding: '1rem',
    backgroundColor: 'rgba(0,0,0,0.4)',
    color: 'white',
  },
};

const handleSubmit = async (e) => {
  e.preventDefault();

  const formData = new FormData();
  Object.keys(recipe).forEach((key) => {
    formData.append(key, recipe[key]);
  });

  try {
    const response = await fetch('http://localhost:5000/api/recipes', {
      method: 'POST',
      body: formData,
    });

    if (response.ok) {
      alert('Recipe added successfully!');
      setRecipe({
        name: '',
        ingredients: '',
        instructions: '',
        category: 'diabetic',
        description: '', // Reset description field
        image: null,
      });
    } else {
      alert('Failed to add recipe.');
    }
  } catch (error) {
    console.error('Error:', error);
  }
};

return (
  <div style={styles.homeContainer}>
      <header style={styles.header}>
        <div>
          <h1 style={styles.logo}>OneStopGo</h1>
        </div>
        <nav style={styles.navbar}>
          {/*<a href="/login" style={{...styles.navLink, ...styles.signIn}}>Sign In</a>*/}
          <a href="/home" style={styles.navLink}>Home</a>
          <a href="/recipeinfo" style={styles.navLink}>Recipes</a>
          <a href="/about" style={styles.navLink}>About Us</a>
          <a href="/contact" style={styles.navLink}>Contact Us</a>
        </nav>
      </header>
      <bgimg></bgimg>
      <main>
  <form onSubmit={handleSubmit}>
    <h2>Add Your Recipe</h2>
    <label>Recipe Name:
      <input type="text" name="name" value={recipe.name} onChange={handleChange} required />
    </label>
    <label>Ingredients:
      <textarea name="ingredients" value={recipe.ingredients} onChange={handleChange} required />
    </label>
    <label>Instructions:
      <textarea name="instructions" value={recipe.instructions} onChange={handleChange} required />
    </label>
    <label>Category:
      <select name="category" value={recipe.category} onChange={handleChange}>
        <option value="diabetic">Diabetes</option>
        <option value="pcos">PCOS</option>
        <option value="school">School Lunches</option>
        <option value="workout">Workout Diet</option>
      </select>
    </label>
    <label>Description: {/* New field for description */}
      <textarea name="description" value={recipe.description} onChange={handleChange} required />
    </label>
    <label htmlFor="food_type">Food Type: </label>
        <select
          id="food_type"
          name="food_type"
          value={foodType}
          onChange={handleChange}
          required
          className="dropdown"
        >
          <option value="">Select Food Type</option>
          <option value="veg">Veg</option>
          <option value="non-veg">Non-Veg</option>
        </select>
    <label>Image:
      <input type="file" name="image" onChange={handleImageChange} />
    </label>
    <button type="submit">Add Recipe</button>
  </form>
  </main>

      <footer style={styles.footer}>
        <p>&copy; 2024 Meal Planner</p>
      </footer>
      
    </div>
);

}

export default AddRecipe;
