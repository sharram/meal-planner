// Register.js
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaEye, FaEyeSlash } from 'react-icons/fa';
import { motion } from "framer-motion";
import '../styles.css';

function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const styles = {
    homeContainer: {
      fontFamily: 'Arial, sans-serif',
      margin: 0,
      padding: 0,
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      backgroundImage: 'url("file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/emerald.jpg")',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      color: 'white',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '1rem 1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
    },
    logo: {
      fontSize: '2rem',
      fontWeight: 'bold',
      color: 'white',
    },
    navbar: {
      display: 'flex',
      alignItems: 'center',
      gap: '1.5rem',
    },
    navLink: {
      textDecoration: 'none',
      color: 'white',
      fontWeight: '500',
      transition: 'color 0.3s ease',
    },
    signIn: {
      //backgroundColor: '#ff6b6b',
      color: '#dccf67',
      padding: '0.5rem 1rem',
      borderRadius: '4px',
    },
    
    footer: {
      textAlign: 'center',
      padding: '0.5rem 0.5rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
      color: 'white',
    },
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleRegister = async (e) => {
  e.preventDefault();

  // Basic validation
  if (!validateEmail(email)) {
    setErrorMessage('Please enter a valid email address.');
    return;
  }
  if (password.length < 8) {
    setErrorMessage('Password must be at least 8 characters long.');
    return;
  }
  if (password !== confirmPassword) {
    setErrorMessage('Passwords do not match.');
    return;
  }

  try {
    const response = await fetch('http://localhost:5000/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, email, password }),
    });

    if (response.ok) {
      alert('Registration successful');
      window.location.href = '/recipeinfo'; // Redirect to RecipeList page
    } else if (response.status === 409) {
      const data = await response.json(); // Parse the JSON response
      if (data.message === 'Username taken') {
        setErrorMessage('Username is already taken. Here are some suggestions:');
        generateUsernameSuggestions(username);
      } else if (data.message === 'Email taken') {
        setErrorMessage('An account with this email already exists.');
      }
    } else {
      const data = await response.json(); // Attempt to parse error response
      setErrorMessage(data.message || 'Registration failed. Try again.');
    }
  } catch (err) {
    console.error('Error during registration:', err);
    setErrorMessage('An error occurred. Please try again later.');
  }
};

  const generateUsernameSuggestions = (baseUsername) => {
    const newSuggestions = Array.from({ length: 3 }, () => `${baseUsername}${Math.floor(Math.random() * 1000)}`);
    setSuggestions(newSuggestions);
  };

  return (
    <div style={styles.homeContainer} >
      <header style={styles.header}>
        <div>
          <h1 style={styles.logo}>OneStopGo</h1>
        </div>
        <nav style={styles.navbar}>
          <a href="/login" style={{...styles.navLink, ...styles.signIn}}>Sign In</a>
          <a href="/home" style={styles.navLink}>Home</a>
          <a href="/" style={styles.navLink}>About Us</a>
          <a href="/contact" style={styles.navLink}>Contact Us</a>
        </nav>
        
      </header>
      

      <main>
        <section>
          <form onSubmit={handleRegister}>
          <h2>REGISTER</h2>
            <label htmlFor="username">Username:</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
            {suggestions.length > 0 && (
              <div className="suggestions">
                <p>Suggestions:</p>
                <ul>
                  {suggestions.map((suggestion, index) => (
                    <li key={index} onClick={() => setUsername(suggestion)}>{suggestion}</li>
                  ))}
                </ul>
              </div>
            )}

            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

<label htmlFor="password">Password:</label>
      <input
        type={showPassword ? 'text' : 'password'}
        id="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
        style={{ paddingRight: '2rem' }} // Adjust space for the icon
      />
      <label
        htmlFor="password"
        onClick={() => setShowPassword(!showPassword)}
        style={{
          position: "absolute",
          right: '460px',
          top: '55.5%',
          transform: 'translateY(-50%)',
          cursor: 'pointer',
        }}
      >
        {showPassword ? <FaEyeSlash /> : <FaEye />}
      </label>
            <label htmlFor="confirmPassword">Confirm Password:</label>
            <input
              type={showConfirmPassword ? 'text' : 'password'}
              id="confirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
            <label
        htmlFor="confirmPassword"
        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
        style={{
          position: 'absolute',
          right: '460px',
          top: '70.5%',
          transform: 'translateY(-50%)',
          cursor: 'pointer',
        }}
      >
        {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
      </label>
            <button type="submit">Register</button>
            {errorMessage && <p className="error-message">{errorMessage}</p>}
            <p><wf>Already have an account? </wf><Link className="link" to="/login">Login here</Link></p>
          </form>
          
        </section>
      </main>
      <bgimg></bgimg>
      <footer style={styles.footer}>
        <p>&copy; 2024 Meal Planner</p>
      </footer>
    </div>
  );
}

export default Register;
