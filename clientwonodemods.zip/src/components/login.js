// Login.js
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaEye, FaEyeSlash } from 'react-icons/fa';

//import AppRoutes from '../AppRoutes';
import '../styles.css';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  //const navigate = useNavigate();

  const styles = {
    homeContainer: {
      fontFamily: 'Arial, sans-serif',
      margin: 0,
      padding: 0,
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      backgroundImage: 'url("file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/emerald.jpg")',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      color: 'white',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '1rem 1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
    },
    logo: {
      fontSize: '2rem',
      fontWeight: 'bold',
      color: 'white',
    },
    navbar: {
      display: 'flex',
      alignItems: 'center',
      gap: '1.5rem',
    },
    navLink: {
      textDecoration: 'none',
      color: 'white',
      fontWeight: '500',
      transition: 'color 0.3s ease',
    },
    signIn: {
      //backgroundColor: '#ff6b6b',
      color: '#dccf67',
      padding: '0.5rem 1rem',
      borderRadius: '4px',
    },
    
    footer: {
      textAlign: 'center',
      padding: '1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
      color: 'white',
    },

    rememberMeContainer: {
      display: 'table',
      alignItems: 'centre',
      marginBottom: '1rem',
      gap: '1.5rem',
      fontSize: '1rem',
      color: 'white',
    },
    rememberMeCheckbox: {
      appearance: 'none',
      width: '1.25rem',
      height: '1.50rem',
      border: '2px solid white',
      borderRadius: '4px',
      outline: 'none',
      cursor: 'pointer',
      transition: 'background-color 0.3s',
      '&:checked': {
        backgroundColor: '#007bff',
        borderColor: '#007bff',
        '&:after': {
          content: '"\\2713"',
          display: 'block',
          color: 'white',
          fontSize: '1rem',
          textAlign: 'center',
          lineHeight: '1.25rem',
        },
      },
    },
    rememberMeLabel: {
      cursor: 'pointer',
    },
  };

  // Load saved credentials on component mount
  useEffect(() => {
  const savedEmail = localStorage.getItem('rememberedEmail');
    if (savedEmail) {
      setEmail(savedEmail);
      setRememberMe(true);
    }
  }, []);

  const handleLogin = async (e) => {

    e.preventDefault();
    console.log('Email:', email, 'Password:', password); // Debug log
    try {
      const response = await fetch('http://localhost:5000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('token', data.token); // Store token in local storage

        if (rememberMe) {
          localStorage.setItem('rememberedEmail', email);
        } else {
          localStorage.removeItem('rememberedEmail');
        }

        window.location.href = '/recipeinfo'; // Redirect to RecipeList page
      } else {
        setErrorMessage('Login failed. Please check your credentials.');
      }
    } catch (err) {
      console.error('Error during login:', err);
      setErrorMessage('An error occurred during login. Please try again later.');
    }
  };

  return (
    <div style={styles.homeContainer}>
      <header style={styles.header}>
        <div>
          <h1 style={styles.logo}>OneStopGo</h1>
        </div>
        <nav style={styles.navbar}>
          <a href="/" style={{...styles.navLink, ...styles.signIn}}>Sign In</a>
          <a href="/home" style={styles.navLink}>Home</a>
          <a href="/about" style={styles.navLink}>About Us</a>
          <a href="/contact" style={styles.navLink}>Contact Us</a>
        </nav>
      </header>
      
      <main>
        <section>
          <form onSubmit={handleLogin} >
            <h2>LOGIN</h2>
            <label htmlFor="username">Registered Email:</label>
            <input
              type="text"
              id="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

<label htmlFor="password">Password:</label>
      <input
        type={showPassword ? 'text' : 'password'}
        id="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
        style={{ paddingRight: '2rem' }} // Adjust space for the icon
      />
      <label
        htmlFor="password"
        onClick={() => setShowPassword(!showPassword)}
        style={{
          position: 'absolute',
          right: '460px',
          top: '49.5%',
          transform: 'translateY(-50%)',
          cursor: 'pointer',
        }}
      >
        {showPassword ? <FaEyeSlash /> : <FaEye />}
      </label>

         {/* New Remember Me checkbox */}
         <div style={styles.rememberMeContainer}>
         Remember Me<input
                type="checkbox"
                id="rememberMe"
                className={styles.rememberMeCheckbox}
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
              />
              <label htmlFor="rememberMe"  style={styles.rememberMeLabel}>
                
              </label>
            </div>

            <button type="submit">Login</button>
            {errorMessage && <p className="error-message">{errorMessage}</p>}
            {/*<p>Forgot your password? <Link class="link" to="/ForgotPassword">Reset here</Link></p>*/}
          <p>Don't have an account? <Link class="link" to="/register">Register here</Link></p>
          </form>

        </section>
      </main>
      <bgimg></bgimg>
      <footer style={styles.footer}>
        <p>&copy; 2024 Meal Planner</p>
      </footer>
    </div>
  );
}

export default Login;
