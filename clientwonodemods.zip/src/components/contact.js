import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../styles.css'; // Import the CSS file

function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('');

  const styles = {
    homeContainer: {
      fontFamily: 'Arial, sans-serif',
      margin: 0,
      padding: 0,
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      backgroundImage: 'url("file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/emerald.jpg")',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      color: 'white',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '1rem 1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
    },
    logo: {
      fontSize: '2rem',
      fontWeight: 'bold',
      color: 'white',
    },
    navbar: {
      display: 'flex',
      alignItems: 'center',
      gap: '1.5rem',
    },
    navLink: {
      textDecoration: 'none',
      color: 'white',
      fontWeight: '500',
      transition: 'color 0.3s ease',
    },
    signIn: {
      //backgroundColor: '#ff6b6b',
      color: '#dccf67',
      padding: '0.5rem 1rem',
      borderRadius: '4px',
    },
    
    footer: {
      textAlign: 'center',
      padding: '1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
      color: 'white',
    },
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        alert('Message sent successfully!');
        setFormData({ name: '', email: '', message: '' });
      } else {
        setStatus('Failed to send the message.');
      }
    } catch (error) {
      console.error('Error submitting contact form:', error);
      setStatus('An error occurred. Please try again later.');
    }
  };

  return (
    <div style={styles.homeContainer}>
      <header style={styles.header}>
        <div>
          <h1 style={styles.logo}>OneStopGo</h1>
        </div>
        <nav style={styles.navbar}>
          <a href="/login" style={{...styles.navLink, ...styles.signIn}}>Sign In</a>
          <a href="/home" style={styles.navLink}>Home</a>
          <a href="/about" style={styles.navLink}>About Us</a>
          <a href="/" style={styles.navLink}>Contact Us</a>
        </nav>
      </header>

      <main>
        <section>
          <h2><wf>Get in Touch With Us!</wf></h2>
          <form onSubmit={handleSubmit}>
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />

            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
            />

            <label htmlFor="message">Message:</label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
            ></textarea>

            <button type="submit">Submit</button>
          </form>
          {status && <p>{status}</p>}
        </section>
      </main>
      <bgimg></bgimg>

      <footer style={styles.footer}>
        <p>&copy; 2024 Meal Planner</p>
      </footer>
    </div>
  );
}

export default Contact;
