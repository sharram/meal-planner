import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { FaPlus } from 'react-icons/fa';

const RecipeList = () => {
  const { category } = useParams();
  const [recipes, setRecipes] = useState([]);
  const [expandedRecipe, setExpandedRecipe] = useState(null);
  const [loading, setLoading] = useState(true);
  const [hoveredButton, setHoveredButton] = useState(null);
  const [hoveredDelete, setHoveredDelete] = useState(false);

  const styles = {
    homeContainer: {
      fontFamily: 'Arial, sans-serif',
      margin: 0,
      padding: 0,
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      backgroundImage: 'url("file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/emerald.jpg")',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      color: 'white',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '1rem 1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
    },
    logo: {
      fontSize: '2rem',
      fontWeight: 'bold',
      color: 'white',
    },
    navbar: {
      display: 'flex',
      alignItems: 'center',
      gap: '1.5rem',
    },
    navLink: {
      textDecoration: 'none',
      color: 'white',
      fontWeight: '500',
      transition: 'color 0.3s ease',
    },
    signIn: {
      color: '#dccf67',
      padding: '0.5rem 1rem',
      borderRadius: '4px',
    },
    footer: {
      textAlign: 'center',
      padding: '1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
      color: 'white',
      marginTop: 'auto',
    },
    main: {
      maxWidth: '48rem',
      margin: '2rem auto',
      padding: '1rem',
      backgroundColor: 'rgba(0, 0, 0, 0.3)',
      borderRadius: '0.75rem',
      flex: '1',
    },
    recipeItem: {
      backgroundColor: 'rgba(255, 255, 255, 0.1)',
      borderRadius: '0.75rem',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
      marginBottom: '1rem',
      overflow: 'hidden',
      transition: 'all 0.3s ease'
    },
    recipeButton: {
      width: '100%',
      padding: '0.75rem 1rem',
      textAlign: 'left',
      fontWeight: '600',
      backgroundColor: 'rgba(255, 255, 255, 0.1)',
      color: 'white',
      border: 'none',
      transition: 'background-color 0.2s',
      cursor: 'pointer',
    },
    buttonHover: {
      backgroundColor: 'rgba(255, 255, 255, 0.2)'
    },
    recipeDetails: {
      backgroundColor: 'rgba(17, 24, 39, 0.9)',
      color: 'white',
      padding: '1rem'
    },
    recipeImage: {
      width: '100%',
      height: '16rem',
      objectFit: 'cover',
      borderRadius: '0.5rem',
      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.2)',
      marginTop: '1rem'
    },
    deleteButton: {
      marginTop: '1rem',
      padding: '0.5rem 1rem',
      backgroundColor: '#dc2626',
      color: 'white',
      borderRadius: '0.25rem',
      transition: 'background-color 0.2s',
      cursor: 'pointer',
      border: 'none',
    },
    deleteButtonHover: {
      backgroundColor: '#b91c1c'
    },
    addRecipeIcon: {
      position: 'fixed',
      bottom: '5rem',
      right: '2rem',
      backgroundColor: '#4CAF50',
      color: 'white',
      width: '3rem',
      height: '3rem',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
      transition: 'transform scale(1.10) 0.2s',
      textDecoration: 'none',
    },
    categoryTitle: {
      textAlign: 'center',
      color: 'white',
      marginBottom: '2rem',
      fontSize: '2rem',
      textTransform: 'capitalize',
    }
  };

  useEffect(() => {
    const fetchRecipes = async () => {
      try {
        setLoading(true);
        const response = await fetch('http://localhost:5000/recipes');
        const data = await response.json();
        const filteredData = category
          ? data.filter(recipe => recipe.category.toLowerCase() === category.toLowerCase())
          : data;
        setRecipes(filteredData);
      } catch (error) {
        console.error('Error fetching recipes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRecipes();
  }, [category]);

  const handleToggleRecipe = (id) => {
    setExpandedRecipe(prev => prev === id ? null : id);
  };

  const handleDeleteRecipe = async (id) => {
    try {
      const response = await fetch(`http://localhost:5000/recipes/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        setRecipes(prevRecipes => prevRecipes.filter(recipe => recipe._id !== id));
      } else {
        console.error('Failed to delete recipe');
      }
    } catch (error) {
      console.error('Error deleting recipe:', error);
    }
  };

  const getCategoryTitle = () => {
    switch (category) {
      case 'diabetic':
        return 'Diabetic Diet Recipes';
      case 'pcos':
        return 'PCOS Diet Recipes';
      case 'workout':
        return 'Workout Diet Recipes';
      case 'school':
        return 'School Lunch Recipes';
      default:
        return `${category ? category.charAt(0).toUpperCase() + category.slice(1) : 'All'} Recipes`;
    }
  };

  return (
    <div style={styles.homeContainer}>
      <header style={styles.header}>
        <div>
          <h1 style={styles.logo}>OneStopGo</h1>
        </div>
        <nav style={styles.navbar}>
          {/*<a href="/login" style={{...styles.navLink, ...styles.signIn}}>Sign In</a>*/}
          <a href="/home" style={styles.navLink}>Home</a>
          <a href="/recipeinfo" style={styles.navLink}>Recipes</a>
          <a href="/about" style={styles.navLink}>About Us</a>
          <a href="/contact" style={styles.navLink}>Contact Us</a>
        </nav>
      </header>

      <main style={styles.main}>
        <h2 style={styles.categoryTitle}>{getCategoryTitle()}</h2>
        {loading ? (
          <p style={{ textAlign: 'center', color: 'white' }}>Loading recipes...</p>
        ) : recipes.length === 0 ? (
          <p style={{ textAlign: 'center', color: 'white' }}>
            {category ? `No recipes found for ${category} category.` : 'No recipes available.'}
          </p>
        ) : (
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            {recipes.map((recipe) => (
              <li key={recipe._id} style={styles.recipeItem}>
                <button 
                  onClick={() => handleToggleRecipe(recipe._id)}
                  onMouseEnter={() => setHoveredButton(recipe._id)}
                  onMouseLeave={() => setHoveredButton(null)}
                  style={{
                    ...styles.recipeButton,
                    ...(hoveredButton === recipe._id ? styles.buttonHover : {})
                  }}
                >
                  {recipe.name}
                  {recipe.food_type === 'veg' ? ' 🥦' : recipe.food_type === 'non-veg' ? ' 🍗' : ''}
                </button>
               
                {expandedRecipe === recipe._id && (
                  <div style={styles.recipeDetails}>
                    <p style={{ marginBottom: '0.5rem' }}><strong>Category:</strong> {recipe.category}</p>
                    <p style={{ marginBottom: '0.5rem' }}><strong>Food Type:</strong> {recipe.food_type}</p>
                    <p style={{ marginBottom: '0.5rem' }}><strong>Ingredients:</strong> {recipe.ingredients}</p>
                    <p style={{ marginBottom: '0.5rem' }}><strong>Instructions:</strong> {recipe.instructions}</p>
                    <p style={{ marginBottom: '0.5rem' }}><strong>Description:</strong> {recipe.description}</p>
                    
                    {recipe.image && (
                      <div>
                        <img
                          src={`http://localhost:5000/${recipe.image}`}
                          alt={recipe.name}
                          style={styles.recipeImage}
                        />
                      </div>
                    )}
                    
                    <button
                      onClick={() => handleDeleteRecipe(recipe._id)}
                      onMouseEnter={() => setHoveredDelete(true)}
                      onMouseLeave={() => setHoveredDelete(false)}
                      style={{
                        ...styles.deleteButton,
                        ...(hoveredDelete ? styles.deleteButtonHover : {})
                      }}
                    >
                      Delete Recipe
                    </button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </main>

      <Link
        to="/AddRecipe"
        style={styles.addRecipeIcon}
        title="Add Recipe"
        className='add-recipe-icon'
      >
        <FaPlus size={24} />
      </Link>
      
      <footer style={styles.footer}>
        <p>&copy; 2024 Meal Planner</p>
      </footer>
    </div>
  );
};

export default RecipeList;