import React, { useState, useEffect } from 'react';

function Home() {
  const [currentThought, setCurrentThought] = useState('');
  const [quoteAuthor, setQuoteAuthor] = useState('');

  const foodThoughts = [
    {
      quote: "Let food be thy medicine and medicine be thy food.",
      author: "Hippocrates",
      category: "Health"
    },
    {
      quote: "Cooking is like love. It should be entered into with abandon or not at all.",
      author: "Harriet Van Horne",
      category: "Cooking"
    },
    {
      quote: "People who love to eat are always the best people.",
      author: "Julia Child",
      category: "Inspiration"
    },
    {
      quote: "Eating is a necessity, but cooking is an art.",
      author: "Unknown",
      category: "Culinary"
    },
    {
      quote: "Good food is the foundation of genuine happiness.",
      author: "Auguste Escoffier",
      category: "Happiness"
    }
  ];

  const nutritionTips = [
    "Stay hydrated! Drink at least 8 glasses of water daily.",
    "Include a variety of colors in your meals for balanced nutrition.",
    "Prep your meals in advance to maintain a healthy diet.",
    "Balance your plate with proteins, complex carbs, and healthy fats.",
    "Mindful eating helps improve digestion and satisfaction.",
    "Add colorful fruits and veggies for nutrients and variety!"
  ];

  useEffect(() => {
    const randomThought = foodThoughts[Math.floor(Math.random() * foodThoughts.length)];
    setCurrentThought(randomThought.quote);
    setQuoteAuthor(randomThought.author);
  }, []);


  const styles = {
    homeContainer: {
      fontFamily: 'Arial, sans-serif',
      margin: 0,
      padding: 0,
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      backgroundImage: 'url("file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/emerald.jpg")',
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      color: 'white',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '1rem 1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
    },
    logo: {
      fontSize: '2rem',
      fontWeight: 'bold',
      color: 'white',
    },
    navbar: {
      display: 'flex',
      alignItems: 'center',
      gap: '1.5rem',
    },
    navLink: {
      textDecoration: 'none',
      color: 'white',
      fontWeight: '500',
      transition: 'color 0.3s ease',
    },
    signIn: {
      //backgroundColor: '#ff6b6b',
      color: '#dccf67',
      padding: '0.5rem 1rem',
      borderRadius: '4px',
    },
    mainContent: {
      display: 'flex',
      flex: 1,
      padding: '2rem',
    },
    leftSection: {
      flex: 2,
      display: 'flex',
      flexWrap: 'wrap',
      gap: '1rem',
      justifyContent: 'center',
      alignItems: 'center',
    },
   /* imageContainer: {
      width: '200px',
      height: '200px',
      borderRadius: '10px',
      overflow: 'hidden',
      boxShadow: '0 4px 6px rgba(0,0,0,0.3)',
    },*/
    imageSection: {
      width: '50%',
      height: '100vh',
      position: 'relative',
      padding: '1.5rem',
      margin: '10px',
    },
    staticImage: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
    },
    foodThoughtsSection: {
      margin: '10px',
      backgroundColor: 'rgba(255,255,255,0.1)',
      padding: '1.5rem',
      borderRadius: '10px',
      boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
      maxHeight: '750px',
      overflow: 'auto',
      fontFamily: 'Georgia, serif',
    },
    quoteStyle: {
      fontStyle: 'italic',
      fontSize: '1.2rem',
      marginBottom: '0.5rem',
      color: '#333',
    },
    authorStyle: {
      textAlign: 'right',
      fontWeight: 'bold',
      color: '#666',
      marginBottom: '1rem',
    },
    tipSection: {
      borderTop: '1px solid #ddd',
      paddingTop: '1rem',
    },
    tipTitle: {
      fontWeight: 'bold',
      marginBottom: '0.5rem',
      color: '#444',
    },
    tipList: {
      listStyleType: 'none',
      padding: 0,
    },
    tipItem: {
      marginBottom: '1.5rem',
      padding: '0.9rem',
      backgroundColor: 'rgba(0,0,0,0.05)',
      borderRadius: '5px',
    },
    footer: {
      textAlign: 'center',
      padding: '1rem',
      backgroundColor: 'rgba(0,0,0,0.4)',
      color: 'white',
    },
  };

  // Placeholder image and GIF URLs (replace with your actual paths)
 /* const mealImages = [
    "file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/vegetables-7102900_1280.jpg",
    "file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/vegetables-5014939_1280.jpg",
    "file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/depth-of-field-1840285_1280.jpg",
    "file:///C:/Users/avgjo/meal-planner/meal-planner/client/src/depth-of-field-1840285_1280.jpg"
  ];

  const foodThoughts = [
    "Eating a balanced diet is key to a healthy lifestyle.",
    "Meal prep can save you time and help you eat healthier.",
    "Cooking is an art that brings people together.",
    "Nutrition is the foundation of good health.",
    "Experiment with new recipes to keep meals exciting!"
  ];*/

  return (
    <div style={styles.homeContainer}>
      <header style={styles.header}>
        <div>
          <h1 style={styles.logo}>OneStopGo</h1>
        </div>
        <nav style={styles.navbar}>
          <a href="/login" style={{...styles.navLink, ...styles.signIn}}>Sign In</a>
          <a href="/" style={styles.navLink}>Home</a>
          <a href="/recipeinfo" style={styles.navLink}>Recipes</a>
          <a href="/about" style={styles.navLink}>About Us</a>
          <a href="/contact" style={styles.navLink}>Contact Us</a>
        </nav>
      </header>
      
      <main style={styles.mainContent}>
        <section style={styles.imageSection}>
          <img 
            src="https://i.ibb.co/KDCYPc5/ai-generated-7894661-1920.jpg" 
            alt="Featured meal" 
            style={styles.staticImage}
          />
        </section>
        
        <div style={styles.foodThoughtsSection}>
      <h2>Food Thoughts of the Day</h2>
      
      <div>
        <p style={styles.quoteStyle}>"{currentThought}"</p>
        <p style={styles.authorStyle}>- {quoteAuthor}</p>
      </div>

      <div style={styles.tipSection}>
        <h3 style={styles.tipTitle}>🥗 Nutrition Tips</h3>
        <ul style={styles.tipList}>
          {nutritionTips.map((tip, index) => (
            <li key={index} style={styles.tipItem}>
              {tip}
            </li>
          ))}
        </ul>
      </div>
    </div>
      </main>
      
      <footer style={styles.footer}>
        <p>&copy; 2024 Meal Planner</p>
      </footer>
    </div>
  );
}

export default Home;