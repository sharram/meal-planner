// ForgotPassword.js
import React, { useState } from 'react';
import { Link } from 'react-router-dom'; // Make sure to import Link from react-router-dom

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handlePasswordReset = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      const response = await fetch('http://localhost:5000/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      const text = await response.text(); // Get the response as text first
      console.log('Response Text:', text); // Log the raw response text

      if (response.ok) {
        try {
          const data = JSON.parse(text);
          setMessage(data.message || 'Check your email for a password reset link');
        } catch (jsonError) {
          console.error('Error parsing JSON:', jsonError);
          setMessage('Password reset email sent, but could not parse server response.');
        }
      } else {
        try {
          const errorData = JSON.parse(text);
          setMessage(errorData.message || 'User  not found or error occurred');
        } catch (jsonError) {
          console.error('Error parsing JSON from error response:', jsonError);
          setMessage(text || 'User  not found or error occurred');
        }
      }
    } catch (err) {
      console.error('Error requesting password reset:', err);
      setMessage('Something went wrong, please try again');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2>Forgot Password</h2>
      <form onSubmit={handlePasswordReset}>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Sending...' : 'Send Password Reset Link'}
        </button>
      </form>
      {message && <p>{message}</p>}
      <p>
        Remembered your password? <Link to="/login">Login here</Link>
      </p>
    </div>
  );
};

export default ForgotPassword;