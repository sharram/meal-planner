import React from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { CSSTransition, TransitionGroup } from "react-transition-group"; // Import CSS transition components

// Import components
import Home from "./components/home";
import About from "./components/about";
import Contact from "./components/contact";
import Login from "./components/login";
import Register from "./components/register";
import RecipeInfo from "./components/recipeinfo";
import RecipeList from "./components/recipelist";
import Recipe from "./components/recipe";
import AddRecipe from "./components/AddRecipe";
import ForgotPassword from "./components/ForgotPassword";

// Import styles
import "./styles.css";

function App() {
  return (
    <Router>
      <div className="App">
        {/* TransitionGroup to wrap Routes for page transitions */}
        <AnimatedRoutes />
      </div>
    </Router>
  );
}

const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <TransitionGroup className="page-wrapper">
      <CSSTransition
        key={location.pathname}
        classNames="page-transition"
        timeout={500} // Duration for the transition (in ms)
      >
        <Routes location={location}>
          <Route path="/login" element={<Login />} />
          {/*<Route path="/" element={<Login />} />*/}
          <Route path="/register" element={<Register />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/recipeinfo" element={<RecipeInfo />} />
          <Route path="/recipelist/:category" element={<RecipeList />} />
          <Route path="/recipe" element={<Recipe />} />
          <Route path="/AddRecipe" element={<AddRecipe />} />
          <Route path="/ForgotPassword" element={<ForgotPassword />} />
        </Routes>
      </CSSTransition>
    </TransitionGroup>
  );
};

export default App;
