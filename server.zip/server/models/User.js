// models/User.js
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  // Add other fields as necessary (e.g., password, name, etc.)
});

const User = mongoose.model('User ', userSchema);

module.exports = User;